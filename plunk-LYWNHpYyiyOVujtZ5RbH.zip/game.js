// GLOBAL VARIALBES
var game = new Phaser.Game(640, 480, Phaser.AUTO, 'pigcat-adventure',{
preload: preload,
create: create,
update: update
}); 

// create Player object
var player;
// create keyboard input Cursors
var cursors;
// create switch to turn game on/off
var gameStarted = false;
// Links to images
var skyImages = 'https://i.imgur.com/ZCWqpAc.png';
var playerSprites = 'http:i.imgur.com/ODpjVpQ.png';
var pigcatSprites = 'https://i.imgur.com/ut53em3.png';

function preload() {
   // Needed to load images from imgur
    game.load.crossOrigin = "anonymous";
    
    // Preload the sky image
    game.load.image("sky", skyImages);
    
  // Preload the heroine sprite sheet
  game.load.spritesheet("heroine", playerSprites, 32, 32); 
}

function create() {
  game.add.sprite(0,0, 'sky');

  player = game.add.sprite(32, 50, "heroine");
  
 // Player walking animatons
 player.animations.add('left', [12, 13,14, 13]);
 player.animations.add('down', [0, 1, 2,1]); 
 player.animations.add('right', [24, 25, 26, 25]);
 player.animations.add('up', [36,37, 38, 37]);
 
 // On mouse press, start the game
  game.input.onDown.add(startGame, this);

 // Listen for key presses
  keyboard = game.input.keyboard.createCursorKeys();
  }

function startGame() {
  if (!gameStarted) {
    gameStarted = true;
  } 
}



function update() {
 if (gameStarted) {
    if (keybooard.left.isDown) {
     player.animations.play('left', 30);
    } else if (keyboard.right.isDown) {
      player.animations.play('right', 30);
    }
  } 
}     
     